﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nesne_tabanli_programlama
{
    public partial class KarHesaplama: Form
    {
        public KarHesaplama()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MainPage.ReturnToMainPage(); // Global form instance'ını kullanarak geri dön
            this.Hide();
        }
    }
}
