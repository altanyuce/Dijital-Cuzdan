﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nesne_tabanli_programlama
{
    public partial class Harcamalarim: Form
    {
        public Harcamalarim()
        {
            InitializeComponent();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            MainPage.ReturnToMainPage(); // Global form instance'ını kullanarak geri dön
            this.Hide();
        }

        private void Harcamalarim_Load(object sender, EventArgs e)
        {
            listBox1.Items.Clear();
            foreach (string harcama in FinanceData.HarcamaListesi)
            {
                listBox1.Items.Add(harcama);
            }
        }
    }
}
