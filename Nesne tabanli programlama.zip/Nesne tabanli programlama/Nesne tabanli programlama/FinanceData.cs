﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nesne_tabanli_programlama
{
    public static class FinanceData
    {
        // Finansal işlemlerde hassasiyet için decimal kullanılır
        public static decimal ToplamBakiye = 0m;

        // Harcamalar listesi (örnek: "Giyim: 150")
        public static List<string> HarcamaListesi = new List<string>();

        // İsteğe bağlı: Harcama ekleme fonksiyonu
        public static void HarcamaEkle(string kategori, decimal tutar)
        {
            ToplamBakiye -= tutar;
            HarcamaListesi.Add($"{kategori}: {tutar}");
        }

        // İsteğe bağlı: Gelir ekleme fonksiyonu
        public static void GelirEkle(decimal tutar)
        {
            ToplamBakiye += tutar;
        }
    }
}
