﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nesne_tabanli_programlama
{
    public partial class GelirGider: Form
    {
        public GelirGider()
        {
            InitializeComponent();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            MainPage anaSayfa = new MainPage();
            anaSayfa.BakiyeGuncelle();
            anaSayfa.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int gelir))
            {
                FinanceData.ToplamBakiye += gelir;
                MessageBox.Show("Gelir eklendi.");
                textBox1.Clear();
            }
            else
            {
                MessageBox.Show("Geçerli bir gelir miktarı giriniz.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            decimal gider;
            bool parsed = decimal.TryParse(textBox2.Text, out gider);
            if (!parsed || gider <= 0)
            {
                MessageBox.Show("Geçerli bir gider miktarı girin.");
                return;
            }

            // Sadece bir checkbox seçili mi kontrol edelim
            CheckBox[] kategoriler = { checkBox1, checkBox2, checkBox3, checkBox4 };
            CheckBox seciliKategori = kategoriler.FirstOrDefault(cb => cb.Checked);

            if (seciliKategori == null)
            {
                MessageBox.Show("Lütfen bir gider kategorisi seçin.");
                return;
            }

            // Bakiyeden çıkar
            FinanceData.ToplamBakiye -= gider;

            // Harcama listesine ekle
            string harcama = $"{seciliKategori.Text}: {gider}";
            FinanceData.HarcamaListesi.Add(harcama);

            MessageBox.Show("Gider eklendi.");

            // CheckBox'ları temizle
            foreach (var cb in kategoriler)
                cb.Checked = false;

            textBox2.Clear();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {
            
        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {
            
        }
    }
}
