﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Nesne_tabanli_programlama
{
    public partial class MainPage: Form
    {
        public static MainPage instance;
        
        
        public MainPage()
        {
            InitializeComponent();
            instance = this;
        }

        public static void ReturnToMainPage()
        {
            instance.Show();
            instance.BringToFront();
        }

        private void MainPage_Load(object sender, EventArgs e)
        {
            lblToplamBakiye.Text = $"Toplam Bakiye: {FinanceData.ToplamBakiye}";
        }
        public void BakiyeGuncelle()
        {
            lblToplamBakiye.Text = $"Toplam Bakiye: {FinanceData.ToplamBakiye}";
        }

        private void button1_Click(object sender, EventArgs e)
        {
            GelirGider gelirGiderForm = new GelirGider(); // Create an instance of GelirGider form
            gelirGiderForm.Show(); // Show the form
            this.Hide(); // Optionally hide the current form (MainPage)
        
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Harcamalarim harcamalarimForm = new Harcamalarim(); // Create an instance of Harcamalarim form
            harcamalarimForm.Show(); // Show the form
            this.Hide(); // Optionally hide the current form (MainPage)
        }

        private void button3_Click(object sender, EventArgs e)
        {
            KarHesaplama karHesaplamaForm = new KarHesaplama(); // Create an instance of KarHesaplama form
            karHesaplamaForm.Show(); // Show the form
            this.Hide(); // Optionally hide the current form (MainPage)
        }
    }
}
